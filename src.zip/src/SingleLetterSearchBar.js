import React, { useState } from 'react';

const SingleLetterSearchBar = ({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState(''); // State for user input

  const handleInputChange = (event) => {
    setSearchTerm(event.target.value); // Update state with input value
  };

  const handleSearchClick = () => {
    if (onSearch) {
      onSearch(searchTerm); // Pass the search term to the parent
    }
  };

  render() {
  return (
    <div>
      <input
        type="text"
        value={searchTerm}
        onChange={handleInputChange}
        placeholder="Enter a letter"
        aria-label="Search for a letter"
      />
      <button type="button" onClick={handleSearchClick}>Search</button>
    </div>
  );
};

export default SingleLetterSearchBar;
