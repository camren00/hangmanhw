import React from 'react';
import SingleLetterSearchBar from './SingleLetterSearchBar';

class ParentComponent extends React.Component {
    state = {
        letters: ['A', 'B', 'C', 'D'], // Example data
        searchResult: null, // Store the search result
    };

    handleSearch = (searchTerm) => {
        console.log('Search term received:', searchTerm); // Debugging
        // Search for the letter in the list (case-insensitive)
        const result = this.state.letters.find(
            (letter) => letter.toUpperCase() === searchTerm.toUpperCase()
        );

        // Update the search result in the state
        this.setState({ searchResult: result || 'No result' });
    };

    render() {
        return (
            <div>
                <h1>Letter Search</h1>
                <SingleLetterSearchBar onSearch={this.handleSearch} />
                <div>
                    <h2>Search Result:</h2>
                    <p>{this.state.searchResult}</p>
                </div>
            </div>
        );
    }
}

export default ParentComponent;